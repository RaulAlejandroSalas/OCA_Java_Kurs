package ml.salastexido;

public class BookTest {
	
	public static void main(String[] args) {
		Book b1 = new Book("Algorithms","AAA","B",150);
		Book b2 = new Book("AlgorithmsI","CC","E",150);
		Book b3 = new Book("AlgorithmsII","DD","R",150);
	}
}
